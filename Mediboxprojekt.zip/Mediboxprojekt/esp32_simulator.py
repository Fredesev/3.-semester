from flask import Flask, request, jsonify

app = Flask(__name__)

# Simuleret endpoint for ESP32
@app.route('/set_times', methods=['POST'])
def set_times():
    data = request.json
    print(f"Modtaget data fra Flask: {data}")
    return jsonify({"status": "success", "message": "Data modtaget af ESP32-simulatoren"}), 200

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)
