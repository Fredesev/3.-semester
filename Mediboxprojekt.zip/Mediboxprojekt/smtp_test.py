import smtplib

try:
    # Opret forbindelse til Outlook SMTP-serveren
    server = smtplib.SMTP('smtp.office365.com', 587)
    server.starttls()  # Start TLS-kryptering

    # Log ind med app-specifik adgangskode
    server.login('mediboxtester@outlook.com', 'Y2CUB-UFYGW-PWLTC-LDQWG-FGNUS')

    # Send en test-e-mail
    server.sendmail(
        'mediboxtester@outlook.com',
        'mediboxtester@outlook.com',  # Udskift med en testmodtagers e-mailadresse
        "Dette er en test-e-mail fra MediBox!"
    )
    print("E-mail sendt!")  # Bekræft, at e-mailen blev sendt
    server.quit()
except Exception as e:
    print("Fejl ved SMTP-forbindelse:", e)  # Udskriv eventuelle fejl
