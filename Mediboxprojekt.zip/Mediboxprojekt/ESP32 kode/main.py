from machine import Pin, PWM, RTC
import time
import ntptime
import network
import urequests  # Til HTTP POST-forespørgsler

# WiFi-indstillinger
SSID = "Dilay"  # Dit WiFi-navn
PASSWORD = "Dilay1313"  # Dit WiFi-adgangskode

# Flask-serverens endpoint
SERVER_URL = "http://192.168.1.100:5000/data"  # Flask-serverens endpoint

# Forbind til WiFi
def connect_wifi():
    wifi = network.WLAN(network.STA_IF)
    wifi.active(True)
    wifi.connect(SSID, PASSWORD)
    print("Forbinder til WiFi...")
    while not wifi.isconnected():
        pass
    print("WiFi forbundet!")
    print("IP-adresse:", wifi.ifconfig()[0])

# Synkroniser tid med NTP-server
def sync_time():
    try:
        ntptime.settime()  # Sæt tiden fra en NTP-server
        print("Tid synkroniseret!")
    except Exception as e:
        print("Kunne ikke synkronisere tiden:", e)

# Send data til Flask-server
def send_to_flask(event, value):
    try:
        data = {"event": event, "value": value}
        response = urequests.post(SERVER_URL, json=data)  # Send data som JSON
        print("Response fra Flask:", response.text)
        response.close()  # Luk forbindelsen
    except Exception as e:
        print("Kunne ikke sende data til Flask:", e)

# LCD Kommando
def lcd_command(cmd):
    RS.value(0)  # Kommando mode
    E.value(1)
    # Skriv de øverste 4 bits
    D4.value((cmd >> 4) & 1)
    D5.value((cmd >> 5) & 1)
    D6.value((cmd >> 6) & 1)
    D7.value((cmd >> 7) & 1)
    E.value(0)
    time.sleep(0.002)  # Forlæng forsinkelsen
    E.value(1)
    # Skriv de nederste 4 bits
    D4.value(cmd & 1)
    D5.value((cmd >> 1) & 1)
    D6.value((cmd >> 2) & 1)
    D7.value((cmd >> 3) & 1)
    E.value(0)
    time.sleep(0.002)  # Forlæng forsinkelsen

# LCD Initiering
def lcd_init():
    time.sleep(0.02)  # Wait for LCD to power up
    lcd_command(0x33)  # Initialization (must be sent 3 times)
    lcd_command(0x32)  # Skift til 4-bit mode
    lcd_command(0x28)  # 2 linjer, 5x8 matrix
    lcd_command(0x0C)  # Display ON, cursor OFF
    lcd_command(0x06)  # Auto increment
    lcd_command(0x01)  # Clear screen
    time.sleep(0.02)   # Wait for the LCD to process the command

# Skriv tekst til LCD
def lcd_write(text):
    for char in text:
        RS.value(1)  # Data mode
        E.value(1)
        # Skriv de øverste 4 bits
        D4.value((ord(char) >> 4) & 1)
        D5.value((ord(char) >> 5) & 1)
        D6.value((ord(char) >> 6) & 1)
        D7.value((ord(char) >> 7) & 1)
        E.value(0)
        time.sleep(0.002)  # Forlæng forsinkelsen
        E.value(1)
        # Skriv de nederste 4 bits
        D4.value(ord(char) & 1)
        D5.value((ord(char) >> 1) & 1)
        D6.value((ord(char) >> 2) & 1)
        D7.value((ord(char) >> 3) & 1)
        E.value(0)
        time.sleep(0.002)  # Forlæng forsinkelsen

# Servo-funktion
def move_servo(angle):
    duty = int((angle / 180 * 102) + 26)  # Beregn duty cycle for vinklen
    servo.duty(duty)

# Konfigurer LED, knapper og servo
led = Pin(23, Pin.OUT)  # LED på GPIO23
button_led = Pin(22, Pin.IN, Pin.PULL_UP)  # LED button på GPIO22 (pill taken button)
button_motor = Pin(25, Pin.IN, Pin.PULL_UP)  # Motor ON/OFF button på GPIO25
servo = PWM(Pin(26), freq=50)  # Servomotor på GPIO26

# Pins til LCD
RS = Pin(15, Pin.OUT)  # RS på GPIO15
E = Pin(2, Pin.OUT)    # E på GPIO2
D4 = Pin(0, Pin.OUT)   # D4 på GPIO0
D5 = Pin(5, Pin.OUT)   # D5 på GPIO4
D6 = Pin(18, Pin.OUT)  # D6 på GPIO5
D7 = Pin(4, Pin.OUT)   # D7 på GPIO18

# Initialisering
lcd_init()
lcd_write("Forbinder WiFi...")
connect_wifi()
time.sleep(1)  # Tilføj forsinkelse efter WiFi
sync_time()
time.sleep(1)  # Tilføj forsinkelse efter tidssynkronisering
lcd_command(0x01)  # Ryd skærmen
lcd_write("System klar!")

# Hovedløkke
motor_on = False  # Initial state of the motor (off)
last_motor_press_time = 0  # Variable to track the last time motor button was pressed
debounce_time = 300  # Milliseconds debounce time for motor button
last_led_press_time = 0  # Variable to track the last time LED button was pressed
led_on_time = 0  # Variable to track when the LED was turned on
led_timeout = 5000  # Time in milliseconds after which the LED should turn off
pill_taken_time = None  # Variable to store the time when pill was taken

while True:
    current_time = time.ticks_ms()  # Get current time in milliseconds
    
    # Hvis LED-knappen trykkes (lav aktiv) - Non-blocking debounce
    if not button_led.value() and (current_time - last_led_press_time > 200):
        last_led_press_time = current_time  # Update the time of the last button press
        pill_taken_time = time.localtime()  # Record the time when the pill was taken
        led.value(1)  # Turn on the LED (indicating pill taken)
        led_on_time = current_time  # Record the time when LED was turned on
        
        # Display pill taken time on LCD
        lcd_command(0x01)  # Clear screen
        time.sleep(0.01)  # Wait a bit for LCD to process
        lcd_write("Pille taget kl:")
        time_str = "{:02}:{:02}:{:02}".format(pill_taken_time[3], pill_taken_time[4], pill_taken_time[5])
        lcd_write(time_str)

        # Send data til Flask-server
        send_to_flask("Pille taget", time_str)

    # Turn off LED automatically after timeout
    if led.value() == 1 and (current_time - led_on_time >= led_timeout):
        led.value(0)  # Turn off the LED after timeout
    
    # Hvis motor ON/OFF knappen trykkes (lav aktiv) - Motor toggle with debounce
    if not button_motor.value() and (current_time - last_motor_press_time > debounce_time):
        last_motor_press_time = current_time  # Update the time of the last button press
        motor_on = not motor_on  # Toggle motor's state
        if motor_on:
            move_servo(90)  # Flyt servo til åben position (servo open)
            send_to_flask("Motor", "Åben")
        else:
            move_servo(0)  # Flyt servo til lukket position (servo closed)
            send_to_flask("Motor", "Lukket")

    time.sleep(0.1)  # Kort pause for at spare CPU
