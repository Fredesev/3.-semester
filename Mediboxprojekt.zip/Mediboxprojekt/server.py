from flask import Flask, jsonify, request
from flask_cors import CORS  # Importer Flask-CORS
from flask_mail import Mail, Message  # Importer Flask-Mail
import sqlite3  # Til SQLite-database
import requests  # Til at sende HTTP-anmodninger til ESP32

app = Flask(__name__)
CORS(app)  


try:
    app.config.from_pyfile('config.py')
    print("Config loaded successfully!")
    print("MAIL_SERVER:", app.config['MAIL_SERVER'])
    print("MAIL_USERNAME:", app.config['MAIL_USERNAME'])
except Exception as e:
    print(f"Failed to load config.py: {e}")

mail = Mail(app)  


def get_db_connection():
    try:
        conn = sqlite3.connect("medibox.db")
        conn.row_factory = sqlite3.Row  
        return conn
    except sqlite3.Error as e:
        print(f"Database connection failed: {e}")
        return None


def create_table():
    conn = get_db_connection()
    if conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            times TEXT,  -- Medicin-tider som en kommasepareret streng
            status TEXT
        )
        """)
        conn.commit()
        conn.close()

create_table()


@app.route('/')
def home():
    return "Velkommen til MediBox API. Gå til /api/users for data."


@app.route('/api/users', methods=['GET'])
def get_users():
    conn = get_db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    users = conn.execute("SELECT * FROM users").fetchall()
    conn.close()
    return jsonify([dict(user) for user in users])


@app.route('/api/notify/<int:user_id>', methods=['POST'])
def send_notification(user_id):
    conn = get_db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()

    if not user:
        return jsonify({"error": "Bruger ikke fundet"}), 404

    try:
        
        msg = Message(
            "Påmindelse fra MediBox",
            recipients=[user["email"]]
        )
        msg.body = f"Hej {user['name']}, husk at tage din medicin kl. {user['times']}."
        mail.send(msg)
        return jsonify({"message": "E-mail sendt til brugeren"}), 200
    except Exception as e:
        print("Fejl ved afsendelse af e-mail:", str(e))
        return jsonify({"error": "Kunne ikke sende e-mail"}), 500


@app.route('/api/users/<int:user_id>/update', methods=['POST'])
def update_user(user_id):
    try:
        data = request.json  
        if not data or not isinstance(data.get("times"), list) or "email" not in data:
            return jsonify({"error": "Invalid input format"}), 400

        conn = get_db_connection()
        if not conn:
            return jsonify({"error": "Database connection failed"}), 500
        user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()

        if not user:
            conn.close()
            return jsonify({"error": "Bruger ikke fundet"}), 404

        
        times = ",".join(data["times"])  
        email = data["email"]
        conn.execute("UPDATE users SET times = ?, email = ? WHERE id = ?", (times, email, user_id))
        conn.commit()
        conn.close()

        
        esp32_ip = "172.20.10.2"  #Esp ip adresse
        esp32_url = f"http://{esp32_ip}/set_times"
        try:
            esp32_response = requests.post(esp32_url, json={
                "times": data["times"],
                "user_id": user_id
            })
            if esp32_response.status_code == 200:
                print("Data sendt til ESP32:", esp32_response.json())
            else:
                print(f"ESP32 returned error: {esp32_response.status_code} - {esp32_response.text}")
        except requests.ConnectionError as ce:
            print("Connection error to ESP32:", ce)
        except Exception as e:
            print("An error occurred while sending data to ESP32:", e)

        
        msg = Message(
            "MediBox Opdatering",
            recipients=[email]
        )
        msg.body = f"Dine medicintider er blevet opdateret til: {times}."
        mail.send(msg)

        return jsonify({"message": "Brugerdata opdateret, sendt til ESP32, og e-mail sendt"}), 200
    except Exception as e:
        print("Fejl i update_user:", str(e))  
        return jsonify({"error": "Intern serverfejl"}), 500


@app.route('/test-email', methods=['GET'])
def test_email():
    try:
        msg = Message(
            "Test-e-mail fra MediBox",
            recipients=["test@example.com"]  
        )
        msg.body = "Dette er en testbesked fra MediBox systemet."
        mail.send(msg)
        return "Test-e-mail sendt!"
    except Exception as e:
        return f"Fejl ved afsendelse af test-e-mail: {e}"


def insert_test_data():
    conn = get_db_connection()
    if not conn:
        print("Database connection failed")
        return
    try:
        conn.execute("""
        INSERT INTO users (name, email, times, status)
        VALUES 
        ('John Doe', 'john@example.com', '08:00,20:00', 'Ready'),
        ('Jane Smith', 'jane@example.com', '09:00,21:00', 'Waiting for user')
        """)
        conn.commit()
    except sqlite3.IntegrityError:
        print("Testdata findes allerede!")
    conn.close()

insert_test_data()


if __name__ == '__main__':
    app.run(debug=False)


