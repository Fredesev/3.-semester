console.log("Admin Dashboard er klar!");

// Når siden indlæses
window.onload = function () {
    console.log("Indlæser brugerdata...");

    // Hent elementet, hvor brugerlisten skal vises
    const userListElement = document.getElementById("userList");

    // Vis en besked, mens data hentes
    userListElement.innerHTML = "<li>Henter brugerdata...</li>";

    // Fetch data fra /api/users
    fetch("http://127.0.0.1:5000/api/users")
        .then((response) => {
            console.log("Fetch response status:", response.status);
            if (!response.ok) {
                throw new Error(`HTTP-fejl! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((users) => {
            console.log("Brugerdata modtaget:", users);

            // Ryd tidligere indhold
            userListElement.innerHTML = "";

            // Tilføj hver bruger til listen
            if (users.length > 0) {
                users.forEach((user) => {
                    const userItem = document.createElement("li");
                    userItem.textContent = `${user.name} (${user.email})`;
                    userItem.classList.add("user-item"); // Giver mulighed for ekstra styling
                    userItem.style.cursor = "pointer";

                    // Klik event for at navigere til brugerens detaljer
                    userItem.addEventListener("click", () => {
                        console.log(`Navigerer til detaljer for bruger ID: ${user.id}`);
                        window.location.href = `user_detail.html?id=${user.id}`;
                    });

                    userListElement.appendChild(userItem);
                });
            } else {
                userListElement.innerHTML = "<li>Ingen registrerede brugere fundet.</li>";
            }
        })
        .catch((error) => {
            console.error("Fejl ved hentning af brugerdata:", error);
            userListElement.innerHTML = "<li>Kunne ikke hente brugerdata. Prøv igen senere.</li>";
        });
};
