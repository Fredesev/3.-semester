// Få fat i formularen og fejlbesked-elementet
const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

// Definer demo-bruger og admin (til simulering)
const demoCredentials = {
    user: {
        email: "user@medibox.com",
        password: "password123",
        dashboard: "index.html"
    },
    admin: {
        email: "admin@medibox.com",
        password: "admin123",
        dashboard: "admin_dashboard.html"
    }
};

// Tilføj en event listener til formularen
loginForm.addEventListener("submit", function (event) {
    event.preventDefault(); // Forhindrer siden i at genindlæses

    // Hent værdier fra inputfelterne
    const role = document.getElementById("role").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Tjek om e-mail og kodeord matcher den valgte rolle
    const credentials = demoCredentials[role];
    if (credentials && email === credentials.email && password === credentials.password) {
        alert(`Login succesfuldt! Velkommen, ${role.charAt(0).toUpperCase() + role.slice(1)}.`);
        // Naviger til det relevante dashboard
        window.location.href = credentials.dashboard;
    } else {
        loginMessage.textContent = "Forkert e-mail eller adgangskode. Prøv igen.";
        loginMessage.style.color = "red"; // Fremhæv fejlen
    }
});
