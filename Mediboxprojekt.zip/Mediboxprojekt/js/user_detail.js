console.log("User Detail Page er klar!");

// Hent query parameter fra URL'en
const urlParams = new URLSearchParams(window.location.search);
const userId = urlParams.get("id");

// Kontroller, om userId findes
if (!userId) {
    console.error("Bruger ID mangler i URL'en.");
    document.getElementById("userDetails").textContent = "Ingen bruger-ID fundet.";
} else {
    // Hent brugerdata fra API
    fetch(`http://127.0.0.1:5000/api/users/${userId}`)
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP-fejl! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((user) => {
            const userDetailsElement = document.getElementById("userDetails");

            if (user) {
                userDetailsElement.innerHTML = `
                    <h2>${user.name}</h2>
                    <p>Email: ${user.email}</p>
                    <p>Medibox status: ${user.status}</p>
                    <p>Tidsplan: ${user.times ? user.times.split(",").join(", ") : "Ingen tidsplan"}</p>
                `;
                document.getElementById("email").value = user.email;
                document.getElementById("times").value = user.times ? user.times.split(",").join(", ") : "";
            } else {
                userDetailsElement.textContent = "Bruger ikke fundet.";
            }
        })
        .catch((error) => {
            console.error("Fejl ved hentning af brugerdata:", error);
            document.getElementById("userDetails").textContent = "Kunne ikke hente brugerdata.";
        });

    // Håndter formularen
    document.getElementById("medicationForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const times = document.getElementById("times").value.split(",").map((t) => t.trim());
        const email = document.getElementById("email").value;

        // Opdater brugerdata via API
        fetch(`http://127.0.0.1:5000/api/users/${userId}/update`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ times, email }),
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`HTTP-fejl! Status: ${response.status}`);
                }
                return response.json();
            })
            .then((data) => {
                console.log("Indstillinger opdateret:", data);
                document.getElementById("responseMessage").textContent = "Indstillinger gemt!";
            })
            .catch((error) => {
                console.error("Fejl ved opdatering:", error);
                document.getElementById("responseMessage").textContent = "Kunne ikke gemme indstillinger.";
            });
    });
}
