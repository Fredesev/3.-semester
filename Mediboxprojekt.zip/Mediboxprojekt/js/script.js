console.log("MediBox Dashboard er klar!");

// Når siden indlæses
window.onload = function () {
    console.log("Siden er indlæst.");

    // Find logs-elementet
    const medLogsElement = document.getElementById("medLogs");

    // Vis feedback, mens logs hentes
    medLogsElement.innerHTML = "<li>Henter logs...</li>"; // Feedback under indlæsning

    // Fetch anmodning til Flask API for medicinlogs
    fetch("http://127.0.0.1:5000/api/logs")
        .then(async response => {
            console.log("Fetch response status:", response.status); // Debug for statuskode
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            const rawText = await response.text();
            console.log("Fetch raw response text:", rawText); // Debug rå tekst
            return JSON.parse(rawText); // Pars rå tekst som JSON
        })
        .then(data => {
            console.log("Hentede data fra serveren:", data); // Debug parsed JSON

            // Ryd tidligere feedback
            medLogsElement.innerHTML = "";

            // Tilføj logs til UI
            data.forEach(log => {
                const logItem = document.createElement("li");
                logItem.textContent = `${log.date} - ${log.time} - Status: ${log.status}`;
                console.log("Tilføjer log til UI:", logItem.textContent); // Debug hver log
                medLogsElement.appendChild(logItem);
            });
        })
        .catch(error => {
            console.error("Error fetching logs:", error); // Debug: Vis fejlen

            // Vis fejlmeddelelse til brugeren
            medLogsElement.innerHTML = "<li>Kunne ikke hente logs. Prøv igen senere.</li>";
        });

    // Håndter knappen for medicinstatus
    document.getElementById("medButton").addEventListener("click", function () {
        const statusMessage = document.getElementById("statusMessage");

        // Simuler feedback til brugeren
        statusMessage.textContent = "Medicinen er taget!";
        setTimeout(() => {
            statusMessage.textContent = "";
        }, 3000); // Fjern besked efter 3 sekunder
    });

    // Håndter log ud-knappen
    document.getElementById("logoutButton").addEventListener("click", function () {
        alert("Du er logget ud!");
        window.location.href = "login.html"; // Naviger til login.html
    });
};



