MAIL_SERVER = 'smtp.office365.com'
MAIL_PORT = 587
MAIL_USE_TLS = True
MAIL_USERNAME = 'mediboxtester@outlook.com'
MAIL_PASSWORD = 'Y2CUB-UFYGW-PWLTC-LDQWG-FGNUS'
MAIL_DEFAULT_SENDER = 'mediboxtester@outlook.com'
